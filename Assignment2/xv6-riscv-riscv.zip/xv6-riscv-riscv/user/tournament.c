#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 2: Tournament Tree

int
main(int argc, char *argv[])
{
    int number = atoi(argv[1]);

    int tournament_id = tournament_create(number);
    
    if(tournament_id >= 0)
    {
        if(tournament_acquire() < 0)
        {
            printf("Failed to acquire lock\n");
            exit(1);
        }

        printf("PID: %d, tournament ID: %d\n", getpid(), tournament_id);

        if(tournament_release() < 0)
        {
            printf("Failed to release lock\n");
            exit(1);
        }
    }

    exit(0);
}