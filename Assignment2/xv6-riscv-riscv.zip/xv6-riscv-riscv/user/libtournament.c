#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 2: Tournament Tree

#define NumberOfProcesses 16
#define NumberOfLevels 4 // log(16) = 4

typedef struct {
    int role;
    int lock_id;
} Level;

typedef Level Path[NumberOfLevels]; 
Path processes_array[NumberOfProcesses];
int locks_array[NumberOfProcesses-1];

int levels = -1;
int tournament_id = -1;

int log2(int n) 
{
    int result = -1;
    while (n) 
    {
        n >>= 1;
        result++;
    }
    return result;
}

int tournament_create(int processes)
{
    if ((processes < 2) || (processes > 16))
        return-1;

    if ((processes & (processes - 1)) != 0)
        return -1;
        
    int fork_ret;
    int lock_id;
    levels = log2(processes);

    for(int i = 0; i < processes-1; i++)
    {
        lock_id = peterson_create();

        if (lock_id < 0)
            return -1;

        locks_array[i] = lock_id;      
    }

    for(int i = 0; i < processes; i++)
    {
        for(int j = 0; j < levels; j++)
        {
            processes_array[i][j].role = (i & (1 << (levels-j-1))) >> (levels-j-1);
            processes_array[i][j].lock_id = (i >> (levels-j)) + (1 << j) - 1;
        }
    }

    for(int i = 0; i < processes; i++)
    {
        fork_ret = fork();

        if (fork_ret < 0)
            return -1;

        else if(fork_ret == 0)
        {
            tournament_id = i;
            return tournament_id; // child
        }
    }

    return -1; // father
}

int tournament_acquire(void)
{
    if (tournament_id < 0)
        return -1;

    int role;
    int lock_id;

    for(int i = levels-1; i >= 0; i--)
    {
        role = processes_array[tournament_id][i].role;
        lock_id = processes_array[tournament_id][i].lock_id;

        if (peterson_acquire(locks_array[lock_id], role) < 0)
            return -1;
    }
    return 0;
}

int tournament_release(void)
{
    if (tournament_id < 0)
        return -1;

    int role;
    int lock_id;

    for(int i = 0; i < levels; i++)
    {
        role = processes_array[tournament_id][i].role;
        lock_id = processes_array[tournament_id][i].lock_id;

        if (peterson_release(locks_array[lock_id], role) < 0)
            return -1;
    }
    return 0;
}