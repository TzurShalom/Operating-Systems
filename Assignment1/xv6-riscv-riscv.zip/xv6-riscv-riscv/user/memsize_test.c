#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 2: Kernelspace and System Calls

int
main(int argc, char *argv[])
{
    printf("Memory size: %d bytes\n", memsize());

    void *ptr = malloc(20 * 1024);

    printf("Memory size: %d bytes\n", memsize());

    free(ptr);

    printf("Memory size: %d bytes\n", memsize());

    exit(0,"");
}