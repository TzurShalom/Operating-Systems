#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 3: Goodbye World

int
main(int argc, char *argv[])
{
    exit(0, "Goodbye World xv6");
}