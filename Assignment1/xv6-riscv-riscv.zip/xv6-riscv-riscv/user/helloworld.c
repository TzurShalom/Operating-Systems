#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 1: Hello World

int
main(int argc, char *argv[])
{
    char str[] = "Hello World xv6";
    write(0, str, strlen(str));
    write(0, "\n", 1);
    exit(0, "Success");
}