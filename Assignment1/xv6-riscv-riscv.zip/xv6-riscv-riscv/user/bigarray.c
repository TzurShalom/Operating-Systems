#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Task 4: Distributing Work by Forking

#define ARRAY_SIZE (1 << 16) // 2^16
#define NUM_CHILDREN 4

int
main(int argc, char *argv[])
{
    //-----------------------------------//
    
    static int array[ARRAY_SIZE];

    int *pids = (int *)malloc(NUM_CHILDREN * sizeof(int)); 
    int *statuses = (int *)malloc(NUM_CHILDREN * sizeof(int));

    //-----------------------------------//

    for (int i = 0; i < ARRAY_SIZE; i++) 
    {
        array[i] = i;
    }

    //-----------------------------------//

    int id = forkn(NUM_CHILDREN, pids);

    //-----------------------------------//

    if (id < 0) // failure
    {
      free(pids); 
      free(statuses); 
      exit(1,"failure - forkn");
    }

    //-----------------------------------//

    else if (id > 0) // child
    {
        int base_chunk = ARRAY_SIZE / NUM_CHILDREN;
        int remainder = ARRAY_SIZE % NUM_CHILDREN;
        
        int start = (id - 1) * base_chunk + (id - 1 < remainder ? id - 1 : remainder);
        int end   = start + base_chunk + (id <= remainder ? 1 : 0);;

        int sum = 0;

        for (int j = start; j < end; j++) 
        {
            sum += array[j];
        }

        exit(sum, ""); 
    }

    //-----------------------------------//

    // father

    int n;

    if (waitall(&n, statuses) < 0) 
    {
        free(pids); 
        free(statuses); 
        exit(1,"failure - waitall");
    }

    //-----------------------------------//

    if (n != NUM_CHILDREN) 
    {
        free(pids); 
        free(statuses); 
        exit(1,"failure - mismatched numbers");
    }

    //-----------------------------------//

    int sum = 0;

    for (int i = 0; i < n; i++) 
    {
        sum += statuses[i];
    }

    printf("%d\n", sum);

    //-----------------------------------//

    free(pids); 
    free(statuses); 
    exit(0, "success");
}