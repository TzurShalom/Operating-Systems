#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define SIZE 4096

int
main(int argc, char *argv[])
{
    int father_pid = getpid();
    int fork_ret = fork();
    uint64 initial_size = (uint64) sbrk(0);
    int unmapping_flag = 0;

    if (fork_ret < 0)
    {
        printf("fork failed\n");
        exit(1);
    }
    else if (fork_ret > 0) // father
    {
        char *buf = malloc(SIZE);

        //----------//

        wait(0);

        printf("buffer content: %s\n", buf);

        free(buf);

        exit(0);
    }
    else // child
    {
        printf("memory size (before the mapping): %d bytes\n", sbrk(0));

        //----------//

        uint64 address = initial_size + (16 * SIZE) - SIZE;
        uint64 va = map_shared_pages(father_pid, getpid(), address, SIZE);

        char *str = (char *)va;
        strcpy(str, "Hello daddy");

        printf("memory size (after the mapping): %d bytes\n", sbrk(0));

        //----------//

        if (unmapping_flag)
        {
            if (unmap_shared_pages(getpid(), va, SIZE) < 0)
            {
                printf("unmap failed\n");
                exit(1);
            }

            printf("memory size (after the unmapping): %d bytes\n", sbrk(0));
        }

        //----------//

        char *buf = malloc(SIZE);

        printf("memory size (after the call to malloc()): %d bytes\n", sbrk(0));

        //----------//

        free(buf);

        exit(0);
    }
}