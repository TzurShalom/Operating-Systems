#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define PROCESSES 8
#define SHARED_MEMORY_SIZE 4096
#define HEADER_SIZE 4
#define MAKE_HEADER(child_index, message_length) ((child_index << 16) | (message_length & 0xFFFF))

int child_id;
uint64 initial_size;
uint64 shared_memory_pointer;
int processes_array[PROCESSES];

char *messages[] = {
    "hello world",
    "simple string for testing purposes only",
    "this is a basic test",
    "short one",
    "a much longer example of a message that spans multiple words and exceeds normal length",
    "tiny",
    "checking shared memory mapping across virtual spaces",
    "another short"
};

int child_process();
int father_process();

int
main(int argc, char *argv[])
{
    int fork_ret;

    for(int i = 0; i < PROCESSES; i++)
    {
        fork_ret = fork();

        if(fork_ret < 0)
            return -1;

        else if(fork_ret > 0)
            processes_array[i] = fork_ret;

        else
        {
            child_id = i;
            initial_size = (uint64) sbrk(0);
            shared_memory_pointer = initial_size;

            // waiting for the father process to map the shared memory
            while((uint64) sbrk(0) <= initial_size)
                yield();
          
            return child_process();
        }
    }

    return father_process();
}

//------------------------------------------------------------//

int child_process()
{
    char *message = messages[child_id];

    int child_index = child_id;
    int message_length = strlen(message);
    uint32 header = MAKE_HEADER(child_index, message_length);

    int ptr_message_length;
    uint64 va = shared_memory_pointer;
    uint32 *ptr;

    // writing the entire message to buffer
    while(va + HEADER_SIZE + message_length < shared_memory_pointer + SHARED_MEMORY_SIZE) // prints the texts repeatedly
    {
        while(va + HEADER_SIZE + message_length < shared_memory_pointer + SHARED_MEMORY_SIZE) // searching for the next available virtual address
        {
            ptr = (uint32*)va;

            if(__sync_val_compare_and_swap(ptr, 0, header) == 0)
            {
                char *message_location = (char*)(ptr + 1); 
                memmove(message_location, message, message_length);
                yield();
            }
            else
            {
                ptr_message_length = *ptr & 0xFFFF;
                va += HEADER_SIZE + ptr_message_length; 
                va = (va + 3) & ~3;
            }
        }
    }

    // writing the message partially to buffer
    if ((va + HEADER_SIZE + message_length >= shared_memory_pointer + SHARED_MEMORY_SIZE) && (va + HEADER_SIZE < shared_memory_pointer + SHARED_MEMORY_SIZE))
    {
        ptr = (uint32*)va;

        if(__sync_val_compare_and_swap(ptr, 0, header) == 0)
        {
            char *message_location = (char*)(ptr + 1);
            uint64 available_space = (shared_memory_pointer + SHARED_MEMORY_SIZE) - (uint64) message_location;
            memmove(message_location, message, available_space);
        }
    }

    return 0;
}

//------------------------------------------------------------//

int father_process()
{
    char *buf = malloc(SHARED_MEMORY_SIZE);
    uint64 size = (uint64) sbrk(0);
    shared_memory_pointer = size - SHARED_MEMORY_SIZE;

    int father_pid = getpid();
    int child_index;
    int message_length;

    uint32 header;
    uint64 available_space;
    int copy_length;

    // maps the shared memory to the child processes
    for(int i = 0; i < PROCESSES; i++)
        map_shared_pages(father_pid, processes_array[i], (uint64) buf, SHARED_MEMORY_SIZE);
  
    // prints the contents of the buffer
    for(uint64 va = shared_memory_pointer; va + HEADER_SIZE < shared_memory_pointer + SHARED_MEMORY_SIZE;)
    {
        header = *(uint32*)va;

        // waiting for child processes to write to buffer
        while(header == 0)
        {
            yield();
            header = *(uint32*)va;
        }

        child_index = (header >> 16) & 0xFFFF;
        message_length = header & 0xFFFF;

        available_space = (shared_memory_pointer + SHARED_MEMORY_SIZE) - (va + HEADER_SIZE);
        copy_length = message_length < available_space ? message_length : available_space;

        char message[copy_length + 1];
        memmove(message, (void *)(va + HEADER_SIZE), copy_length);
        message[copy_length] = '\0';

        printf("child %d: %s, virtual address: %d\n", child_index, message, va);

        va += HEADER_SIZE + copy_length;
        va = (va + 3) & ~3;
    }

    printf("buffer overflow\n");

    free(buf);
    return 0;
}

//--------------------------------------------------------------------------------------------------------------//